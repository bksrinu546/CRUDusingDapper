﻿using System;

namespace ProductClassLibrary
{
    public class Class1
    {
    }
}
