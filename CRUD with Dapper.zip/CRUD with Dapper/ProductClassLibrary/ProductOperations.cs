﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using Dapper.Contrib.Extensions;

namespace ProductClassLibrary
{
    public class ProductOperations
    {
        DBContext dbconn;
        public ProductOperations(DBContext _dbConn)
        {
            dbconn = _dbConn;
        }
        public List<Product> GetProducts()
        {
            string sql = "SELECT * FROM Products";
            List<Product> prods = new List<Product>();
            prods = dbconn.db.Query<Product>(sql).ToList();
            return prods;
        }
        public Product GetProduct(int ProductId)
        {
            string sql = "SELECT * FROM Products where ProductId=" + ProductId;
            Product prod = new Product();
            prod = dbconn.db.QueryFirstOrDefault<Product>(sql);
            return prod;
        }
        public void InsertOrUpdateProduct(Product prod, int type)
        {
            if (type == 0)
                dbconn.db.Insert(prod);
            else if (type == 1)
                dbconn.db.Update(prod);
           
        }
        public void DeleteProduct(int ProductId)
        {
            string sql = "Delete FROM Products where ProductId=" + ProductId;
            dbconn.db.Execute(sql);
            
        }
    }
}
