﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProductClassLibrary;
namespace DataSaveWithDaper.Controllers
{
    public class ProductsController : Controller
    {
        ProductOperations prodOperations;
        public ProductsController(ProductOperations _prodOperations)
        {
            prodOperations = _prodOperations;
        }
        public IActionResult Index()
        {
            List<Product> lstprods = new List<Product>();
            lstprods = prodOperations.GetProducts();
            return View(lstprods);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Product product)
        {
            prodOperations.InsertOrUpdateProduct(product,0);
            List<Product> lstprods = new List<Product>();
            lstprods = prodOperations.GetProducts();
            return RedirectToAction("Index");
        }
        public IActionResult Edit(int ProductId)
        {
            Product prod = new Product();
            prod = prodOperations.GetProduct(ProductId);
            return View(prod);
        }
        [HttpPost]
        public IActionResult Edit(Product product)
        {
            prodOperations.InsertOrUpdateProduct(product,1);
            List<Product> lstprods = new List<Product>();
            lstprods = prodOperations.GetProducts();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int ProductId)
        {
            prodOperations.DeleteProduct(ProductId);
            List<Product> lstprods = new List<Product>();
            lstprods = prodOperations.GetProducts();
            return RedirectToAction("Index");
        }

    }
}
